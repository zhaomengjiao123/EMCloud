<template>
  <div>
    产品信息
  </div>
</template>

<script>
export default {
  name: "pro_info"
}
</script>

<style scoped>

</style>