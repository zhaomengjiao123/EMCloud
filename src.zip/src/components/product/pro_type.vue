<template>
  <div>
    产品类型
  </div>
</template>

<script>
export default {
  name: "product"
}
</script>

<style scoped>

</style>