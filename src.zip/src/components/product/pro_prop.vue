<template>
  <div>
    产品属性
  </div>
</template>

<script>
export default {
  name: "pro_prop"
}
</script>

<style scoped>

</style>