<template>
  <div>
    产品监控
  </div>
</template>

<script>
export default {
  name: "pro_monitor"
}
</script>

<style scoped>

</style>