<template>
  <div>
    告警处理
  </div>
</template>


<script>
export default {
  name: "pro_warn"
}
</script>

<style scoped>

</style>