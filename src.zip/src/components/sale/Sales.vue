<template>
  <div>
    销售管理
  </div>
</template>

<script>
export default {
  name: "Sales"
}
</script>

<style scoped>

</style>